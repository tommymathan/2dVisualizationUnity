README!!!

***--To load OpenGL into Visual studio---***

1. open the project
2. under view file menu, select toolbox
3. once opened. click anywhere and select choose items...
4. A window will open up.
5. click browse and browse the other unzipped folder named OpenTK
6. select OpenTK.GLControl.dll
7. Great!! now YOu can add an opengl window to the windows form!!